public abstract class Proc extends Global{
	public abstract void TreatSignal(Signal x);
}

